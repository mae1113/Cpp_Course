#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
    struct student {
        char name[51];
        int stuid;    
    };
bool comparestuid(const student& a, const student& b){
    return a.stuid < b.stuid;
}

int main() {
student stud[100];
int numofstu;
numofstu =0;
// get user input 
cout << "Enter student names, and ID, and input END to finish the input:";
    for (int i=0; i<100; i++) {  
        char temp[51];
        cin.getline(temp, 51, '\n');
        //end input when user input END
        if (strcmp(temp, "END")==0)
            break;
        //remove enter 
        if (cin.peek() == '\n') {
            cin.ignore(1, '\n');
        } 
        // separate name and ID by space and store them into respective elements
        char* spacePos = strchr(temp, ' ');
        if (spacePos != nullptr) {
            *spacePos = '\0';
            strcpy(stud[i].name, temp);
            stud[i].stuid = stoi(spacePos +1);
        }
        numofstu++;   
    }

sort (stud, stud + numofstu, comparestuid);
for (int i=0;i<numofstu;i++){
    cout << stud[i].name << " " << stud[i].stuid << endl;
} 
    return 0;
}

