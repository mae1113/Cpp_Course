#include <iostream>
using namespace std;
int main() {
int num [1000];
int inp;
int sum=0;
int i=0;
int size=0;


cout << "Enter a sequence of integer (-999 to finish):";

while (cin>> inp && inp != -999) {
    num[size]= inp;
    size++;
    
}

for (i = 0; i < size ; i++) {
    if(i%2==0) {
        sum += num[i];
    }
    else {
        sum -= num[i];
    }
}
cout << sum;
    return 0;
}