#include <iostream>
#include <cmath>
using namespace std;
int main() {
int choice;
cout << "Meun\n\t1. Divide, a/b\n\t2. Multiply, a*b\n\t3. Power, a^b\n\t4. Square root, sqrt(a)\nEnter your choice:";
cin >> choice;
if (choice == 1) {
    int a,b;
    cout << "Enter two number:";
    cin >> a >> b; 
    float res = (float)a/b;
    cout << a<<"/"<<b <<"="<<res; 
}
if (choice == 2) {
    int a,b;
    cout << "Enter two number:";
    cin >> a >> b; 
    float res = a*b;
    cout << a<<"*"<<b <<"="<<res; 
}
if (choice == 3) {
    int a,b;
    cout << "Enter two number:";
    cin >> a >> b; 
    float res = pow(a, b);
    cout << a<<"^"<<b <<"="<<res;
}
if (choice == 4) {
    int a;
    cout << "Enter a number:";
    cin >> a; 
    float res = sqrt(a);
    cout << "sqrt("<<a<<")="<<res;
}
return 0;
}