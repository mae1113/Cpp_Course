#include <iostream>
#include <cstring>
#include <cctype>
#include <algorithm>
using namespace std;
    char namelist[200][51];
    int numofname;
bool validity(const char* name){
    for (int i=0; i<int(strlen(name));i++) {
        if(name[i] == ' '|| isalpha(name[i])== 0 ){
            return false;
            cin.clear();
            cin.ignore(int(strlen(name)),'\n');
                    
            break;}
 
    } 
    return true;   
}    
bool comparsion(const char* name1, const char* name2){
    return strcmp(name1,name2)<0;
}

int main() {
numofname =0;
// get user input and check validity
cout << "Enter student names and input END to finish the input:";
    while (numofname<200) {    
        cin.getline(namelist[numofname], 51, '\n');
        //end input when user input END
        if (strcmp(namelist[numofname], "END")==0)
            break;
        //check valid input
        
            if (!validity(namelist[numofname])) {
                cout << "Wrong input: please input only upper-case and low-case letters with no space in between" <<endl;    
                continue;
            }
        
        //remove enter 
        if (cin.peek() == '\n') {
            cin.ignore(1, '\n');
        }        
        numofname++;   
    }

//make uppercase
for (int i =0; i<numofname; i++){
    for (int j=0; j< int(strlen(namelist[i]));j++ ){
        if (namelist[i][j]>='a'&&namelist[i][j]<='z'){
            namelist[i][j]=namelist[i][j]-'a'+'A';
        }
    }
}
char* namelistPtr[numofname];
for(int i=0; i<numofname; i++){
    namelistPtr[i]= namelist[i];
}

sort(namelistPtr,namelistPtr+ numofname,comparsion);
for (int i=0;i<numofname;i++){
        cout << namelistPtr[i]<<endl;
}    
    return 0;
}

