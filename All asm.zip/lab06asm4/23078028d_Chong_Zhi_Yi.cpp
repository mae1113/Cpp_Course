#include <iostream>
using namespace std;
void swap (int&, int&);
void sortodd(int[], int);
void sorteven(int[], int);

int main() {
int array1[500];
int array2[500];
int inp;
int size1=0;
int size2=0;
cout << "Enter a sequence of integer (-999 to finish):";

    while (cin>> inp && inp != -999) {
        if (inp%2!=0) {
            array1[size1]=inp;
            size1++;
        }
        else {
            array2[size2]=inp;
            size2++;
        }
    }   

sorteven(array2, size2);
sortodd(array1, size1);

for (int i = 0; i < size1 ; i++) {
cout << array1[i] << " " ;
}
for (int i =0; i < size2 ; i++) {
cout << array2[i] << " " ;
}
cout << endl;
    return 0;
}

// swap 2 elements
void swap(int& a, int& b) {
int temp;
temp = a;
a = b;
b = temp;
}
// sort array odd 
void sortodd(int array[], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - 1; j++) {
            if (array[j] > array[j + 1]) {
                swap(array[j], array[j + 1]);
                }
            }
        }
    }
// sort array even
void sorteven(int array[],int size) {
for (int i=0; i<size -1; i++) {
    for (int j =0; j< size -1; j++) {
        if (array[j]<array[j+1]) {
            swap(array[j],array[j+1]);
            }
        }
    }
}
