#include <iostream>
#include <iomanip>
using namespace std;
int size=0;
double sum =0;
void largest(int[], int);
void smallest(int[], int);
void total(int[], int);
void average();
int main() {
int array[1000];
int inp;
    cout << "Enter a sequence of integer (-999 to finish):";
    while (cin>> inp && inp != -999) {
            array[size]=inp;
            size++;}
largest (array, size) ;
smallest (array, size);
total(array, size);
average();
    return 0;
}

void largest(int array[], int size) {
    int largest =0;
    for (int i= 0; i < size; i++) {
        if (array[i] >= largest) {
            largest = array[i];
        }
    }
    cout << "Largest Number is " << largest  << endl;
}

void smallest(int array[], int size) {
    int smallest = 1;
    for (int i= 0; i < size; i++) {
        if (array[i] <= smallest) {
            smallest = array[i];
        }
    }
    cout << "Smallest Number is " << smallest << endl;
}
void total(int array[], int size) {
    
    for (int i=0; i<size; i++) {
        sum += array[i];
    }
    cout << "Total is " << sum << endl;
}

void average() {
    double average = sum/size;
cout << "Average is " <<fixed << setprecision(3) << average << endl;
}