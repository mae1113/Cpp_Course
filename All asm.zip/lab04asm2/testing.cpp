#include <iostream>
using namespace std;
int main() {
int order=1,branch;
cout << "order (1) or reverse order (2):";
cin >> order;
cout << "please input the branch size:";
cin >> branch;
int b = branch -1;
int d = branch -2;

if (order == 1) {
    char c = 'A';
    //leaves 
    for (int i = 0, x=1; i<branch ;i++,x+=2,b--,d--){
        //space in front
        for(int i= 0; i <b; i++){
            cout << " ";}
        int j;
        //alphabet 
        for ( c = c , j =0  ; j < x;j++,c++) {
            cout << c;
            if (c =='Z'){
                c = '@';}
            }
        //space behind
        for(int i= 0; i <d ; i++){
            cout << " ";}
            cout <<endl;
        }
    char e = c ; //save c
    //trunk
    for(int g=0,  c = e ;g < branch/2;c++,g++){
        for (int f=0; f<branch-2 ;f++){
            cout << " ";}
        cout << char(c)<<" "<<char(c) << endl;  
        }
        }
else { //reverse
    char r = 'Z';
    //leaves
    for (int i = 0, x=1; i<branch ;i++,x+=2,b--,d--){
        //space in front
        for(int i= 0; i <b; i++){
            cout << " ";}
        int j;
        //alphabet
        for ( r = r , j =0  ; j < x;j++,r--) {
            cout << r;
            if (r =='A'){
                r = '[';}
            }
        //space behind
        for(int i= 0; i <d ; i++){
            cout << " ";}
            cout <<endl;
        }
    char p = r ;//save r
    //trunk
    for(int g=0,  r = p ;g < branch/2;r--,g++){
        for (int f=0; f<branch-2 ;f++){
            cout << " ";}

        cout << char(r)<<" "<<char(r) << endl;  
}
}
return 0;
}