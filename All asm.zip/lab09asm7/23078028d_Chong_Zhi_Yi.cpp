#include <iostream>
using namespace std;
void rotate(char *charArray, int *sizeOfArray);
char charArray[100];
int sizeOfArray=0;
int main() {
    cin.get(charArray, 100); 
    cin.ignore();
    for (int i=0; charArray[i]!='\0';i++){
        sizeOfArray++;
    }

    for (int i=0; i<sizeOfArray ;i++){
        rotate(charArray,&sizeOfArray);
        cout << charArray << endl;
    }

    return 0; 
}
void rotate(char *charArray, int *sizeOfArray){
    char last = charArray[0];
    for (int i = 0 ; i< *sizeOfArray-1; i++){
        charArray[i] = charArray[i+1];    
    }
    charArray[*sizeOfArray-1]=last;
}